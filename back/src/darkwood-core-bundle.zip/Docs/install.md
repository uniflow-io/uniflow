
Installation SF2
-----------------

### Ajouter à votre composer.json

```
    "require": {
        "Darkwood/core-bundle": "dev-master"
    }
```

et le repository privé

```
    "require": {
        /*** something ***/
    },
    "repositories": [
        {
            "type": "vcs",
            "url": "git@Darkwood.git.beanstalkapp.com:/Darkwood/by-core-bundle.git"
        }
    ],
    /*** something ***/
```

### Ajouter à votre Kernel
```
new Darkwood\CoreBundle\CoreBundle(),
```