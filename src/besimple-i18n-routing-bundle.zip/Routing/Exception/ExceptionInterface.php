<?php
namespace BeSimple\I18nRoutingBundle\Routing\Exception;

/**
 * ExceptionInterface
 *
 * @author Warnar Boekkooi <warnar@boekkooi.net>
 *
 * @api
 */
interface ExceptionInterface
{
}
